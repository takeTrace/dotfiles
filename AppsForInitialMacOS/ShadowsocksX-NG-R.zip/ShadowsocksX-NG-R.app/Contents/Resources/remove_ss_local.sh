#!/bin/sh

#  remove_ss_local.sh
#  ShadowsocksX-NG
#
#  Created by ParadiseDuo on 2020/3/18.
#  Copyright © 2020 qiuyuzhou. All rights reserved.


rm -f "$HOME/Library/LaunchAgents/com.qiuyuzhou.shadowsocksX-NG.local.plist"


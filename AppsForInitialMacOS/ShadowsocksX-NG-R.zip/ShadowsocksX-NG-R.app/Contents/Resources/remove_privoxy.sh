#!/bin/sh

#  remove_privoxy.sh
#  ShadowsocksX-NG
#
#  Created by ParadiseDuo on 2020/3/18.
#  Copyright © 2020 qiuyuzhou. All rights reserved.


rm -f "$HOME/Library/LaunchAgents/com.qiuyuzhou.shadowsocksX-NG.http.plist"

